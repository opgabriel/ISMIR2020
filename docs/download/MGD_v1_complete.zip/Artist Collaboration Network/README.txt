
+-------------------------------------+
|    Artist Collaboration Network	  |
+-------------------------------------+

The networks of collaborating artists obtained from Spotify Charts for each considered market and year. Artists are linked when they collaborate on a hit song (i.e. this song appears on a Spotify Top 200 Chart). As genres are linked to artists, these networks are used as an intermediate step to generate the final Genre Collaboration Networks. 

+---------------------------------------------------------------------------+

╔════════════════════════════════════════════════════════════════════╗
║                             FOLDERS                                ║
╠════════════╦═══════════════════════════════════════════════════════╣
║     au     ║   Artist networks for Australia (2017-19).            ║
╠════════════╬═══════════════════════════════════════════════════════╣
║     br     ║   Artist networks for Brazil (2017-19).               ║
╠════════════╬═══════════════════════════════════════════════════════╣
║     ca     ║   Artist networks for Canada (2017-19).               ║
╠════════════╬═══════════════════════════════════════════════════════╣
║     de     ║   Artist networks for Germany (2017-19).              ║
╠════════════╬═══════════════════════════════════════════════════════╣
║     fr     ║   Artist networks for France (2017-19).               ║
╠════════════╬═══════════════════════════════════════════════════════╣
║     gb     ║   Artist networks for the United Kingdom (2017-19).   ║
╠════════════╬═══════════════════════════════════════════════════════╣
║   global   ║   Artist networks for all markets (2017-19).          ║
╠════════════╬═══════════════════════════════════════════════════════╣
║     jp     ║   Artist networks for Japan (2017-19).                ║
╠════════════╬═══════════════════════════════════════════════════════╣
║     us     ║   Artist networks for the United States (2017-19).    ║
╚════════════╩═══════════════════════════════════════════════════════╝